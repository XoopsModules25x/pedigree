<?php   
/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/
/**
 * animal module for xoops
 *
 * @copyright       The TXMod XOOPS Project http://sourceforge.net/projects/thmod/
 * @copyright       The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license         GPL 2.0 or later
 * @package         animal
 * @since           2.5.x
 * @author          XOOPS Development Team ( name@site.com ) - ( http://xoops.org )
 * @version         $Id: const_entete.php 9860 2012-07-13 10:41:41Z txmodxoops $
 */
	
if (!defined("XOOPS_ROOT_PATH")) {
	die("XOOPS root path not defined");
}

class pedigree_owner extends XoopsObject
{ 
	//Constructor
	function __construct()
	{
		$this->XoopsObject();
		$this->initVar("ID", XOBJ_DTYPE_INT, null, false, 11);
		$this->initVar("firstname", XOBJ_DTYPE_TXTBOX, null, false, 30);
		$this->initVar("lastname", XOBJ_DTYPE_TXTBOX, null, false, 30);
		$this->initVar("postcode", XOBJ_DTYPE_TXTBOX, null, false, 7);
		$this->initVar("woonplaats", XOBJ_DTYPE_TXTBOX, null, false, 50);
		$this->initVar("streetname", XOBJ_DTYPE_TXTBOX, null, false, 40);
		$this->initVar("housenumber", XOBJ_DTYPE_TXTBOX, null, false, 6);
		$this->initVar("phonenumber", XOBJ_DTYPE_TXTBOX, null, false, 14);
		$this->initVar("emailadres", XOBJ_DTYPE_TXTBOX, null, false, 40);
		$this->initVar("website", XOBJ_DTYPE_TXTBOX, null, false, 60);
		$this->initVar("user", XOBJ_DTYPE_TXTBOX, null, false, 20);
					
	}

	function getForm($action = false)
	{
		global $xoopsDB, $xoopsModuleConfig;
	
		if ($action === false) {
			$action = $_SERVER["REQUEST_URI"];
		}
	
		$title = $this->isNew() ? sprintf(_AM_PEDIGREE_EIGENAAR_ADD) : sprintf(_AM_PEDIGREE_EIGENAAR_EDIT);

		include_once(XOOPS_ROOT_PATH."/class/xoopsformloader.php");

		$form = new XoopsThemeForm($title, "form", $action, "post", true);
		$form->setExtra('enctype="multipart/form-data"');
		
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_FIRSTNAME, "firstname", 50, 255, $this->getVar("firstname")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_LASTNAME, "lastname", 50, 255, $this->getVar("lastname")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_POSTCODE, "postcode", 50, 255, $this->getVar("postcode")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_WOONPLAATS, "woonplaats", 50, 255, $this->getVar("woonplaats")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_STREETNAME, "streetname", 50, 255, $this->getVar("streetname")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_HOUSENUMBER, "housenumber", 50, 255, $this->getVar("housenumber")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_PHONENUMBER, "phonenumber", 50, 255, $this->getVar("phonenumber")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_EMAILADRES, "emailadres", 50, 255, $this->getVar("emailadres")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_WEBSITE, "website", 50, 255, $this->getVar("website")), false);
		$form->addElement(new XoopsFormText(_AM_PEDIGREE_EIGENAAR_USER, "user", 50, 255, $this->getVar("user")), false);
		
		$form->addElement(new XoopsFormHidden("op", "save_eigenaar"));


		//Submit buttons
		$button_tray   = new XoopsFormElementTray("", "");
		$submit_button = new XoopsFormButton("", "submit", _SUBMIT, "submit");
		$button_tray->addElement($submit_button);

		$cancel_button = new XoopsFormButton("", "", _CANCEL, "cancel");
		$cancel_button->setExtra('onclick="history.go(-1)"');
		$button_tray->addElement($cancel_button);

		$form->addElement($button_tray);

		return $form;
	}
}
class pedigreeOwnerHandler extends XoopsPersistableObjectHandler
{
	function __construct(&$db) 
	{
		parent::__construct($db, "mod_pedigree_owner", "pedigree_owner", "ID", "firstname");
	}
}	
?>